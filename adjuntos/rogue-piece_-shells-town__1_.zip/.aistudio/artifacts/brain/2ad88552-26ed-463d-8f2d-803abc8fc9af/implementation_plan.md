# Arquitectura Modular de Personajes y Ajustes de Combate

Refactorización integral del motor de personajes para que cada pirata sea un módulo autocontenido y registrable sin modificar el núcleo del juego, acompañada de cuatro correcciones de mecánicas solicitadas (drenaje dinámico de Gear 2nd y Gura Gura, escalado de Coup de Vent con Cola y eliminación de la pausa post-combo de Luffy PTS).

## User Review & Critical Decisions

> [!IMPORTANT] Todas las decisiones clave de arquitectura y balance han sido confirmadas. Durante la ejecución se priorizará primero completar la refactorización modular conservando el 100% del gameplay actual intacto, y como tarea final se aplicarán las 4 correcciones de combate confirmadas.

- **Prioridad de ejecución**: Primero completar y verificar toda la arquitectura modular de personajes; aplicar al final los ajustes de mecánicas y balance.
- **Gear 2nd de Luffy PTS (Confirmado)**: La duración depende de la carga acumulada en la barra de G2; mientras está activo se drena continuamente hasta llegar a 0 (sin recargarse durante la transformación) y al agotarse la habilidad entra en cooldown y el recurso vuelve a cargarse al derrotar enemigos.
- **Gura Gura / Island Shaking H3 de Barbablanca (Confirmado)**: Mismo comportamiento: la duración depende de la barra Gura acumulada, se consume progresivamente mientras la zona está activa y al llegar a 0 (o al cancelar manualmente) la habilidad entra en cooldown y la barra puede volver a cargarse.
- **Cooldown de básicos de Luffy (Confirmado)**: Se elimina únicamente la pausa plana de 1.0s tras completar el 4º golpe (Jet Bazooka) del combo de Luffy PTS.
- **Cola de Franky en Coup de Vent (Confirmado)**: Al lanzar Coup de Vent (H3), se consume la Cola acumulada al instante para escalar proporcionalmente tanto el daño como el área del cono según la Cola disponible en ese momento.

---

## 1. Overview & Core Concept

- **Qué resuelve**: Actualmente, los 12 piratas jugables dependen de decenas de condicionales dispersos por todo el motor (combate, bucle principal, físicas, IA de enemigos, entrada táctil, renderizado y HTML estático), lo que obliga a editar múltiples subsistemas cada vez que se agrega un personaje.
- **Objetivo principal**: Convertir cada personaje en una unidad independiente bajo un contrato unificado (`CharacterDefinition` + ciclo de vida, renderizado y recursos propios), logrando que añadir un futuro pirata de One Piece requiera únicamente crear su módulo y registrarlo en el catálogo central.
- **Valor añadido**: Reducción estimada del 70%–80% en trabajo repetitivo, menor riesgo de regresiones entre personajes, selector de personajes y barras de HUD generados automáticamente desde datos, y resolución limpia de las cuatro mecánicas subutilizadas.

---

## 2. User Experience & Visual Design

- **Identidad visual y estética preservadas**: Se mantiene intacta la estética *Shells Town* de One Piece (paleta dorada `#F5C518` / `#C8A951`, pergaminos `#F4E4C1`, marcos con borde oscuro, barras segmentadas, colores por rareza Común/Raro/Épico/Legendario y los VFX procedurales actuales en Canvas 2D).
- **Flujo de selección dinámico**:
  - El carrusel horizontal, las tarjetas por rareza, las barras animadas de atributos, las píldoras de habilidades y los indicadores de paginación se construyen automáticamente a partir del registro de personajes, manteniendo exactamente el mismo diseño, animaciones de expansión, destello de selección y vistas previas animadas en Canvas.
- **Flujo de HUD y feedback en combate**:
  - El HUD superior izquierdo conserva el retrato, insignia de rareza, barra de HP y un contenedor unificado de recurso/cargas capaz de mostrar barra de progreso, texto dinámico, cargas discretas (pips) o botones de acción contextuales (como el botón de cancelación o insignias bloqueadas) según lo que declare el personaje activo.
  - Los botones de habilidad y ataque reflejan automáticamente cargas, cadenas, bloqueos contextuales o estado de carga sostenida mediante un contrato de estado de botones por personaje.
- **Comportamiento visual de las 4 correcciones de combate**:
  - **Luffy PTS (Gear 2nd)**: La barra roja de G2 baja suavemente en tiempo real mientras emana vapor; no sube al matar enemigos hasta que termine el modo. Al llegar a 0, el botón H2 sale de `ACTIVE`, inicia su cooldown de 18s y las bajas vuelven a llenar la barra.
  - **Barbablanca (Island Shaking H3)**: La barra blanca/gris Gura se consume en tiempo real mientras la zona sísmica y las grietas rodean a Barbablanca; si se cancela manualmente o la barra llega a 0, la zona se cierra con su animación suave, el botón `CANCEL` desaparece, H3 entra en cooldown de 20s y la energía Gura vuelve a poder acumularse.
  - **Franky (Coup de Vent H3)**: Consume la Cola actual y muestra feedback proporcional al nivel de Cola invertido (tanto el radio/cono visual del vendaval como su daño crecen con la Cola gastada).
  - **Luffy PTS (Combo básico)**: Tras Jet Bazooka (4º golpe), mantiene únicamente la cadencia normal del combo sin el bloqueo de 1.0s ni el spinner de cooldown en el botón de ataque.

---

## 3. Key Product Decisions & Trade-Offs

- **Contrato único por personaje vs. herencia rígida**:
  - *Enfoque elegido*: Composición mediante objeto/módulo declarativo con hooks opcionales (`combat`, `renderer`, `hud`, `passiveHooks`, `holdSkill`).
  - *Por qué*: Cada pirata de One Piece tiene mecánicas muy distintas (cadenas de teletransporte, áreas con cancelación manual, ataques cargados, transformaciones, trampas); los hooks opcionales permiten expresar peculiaridades sin inflar una clase base ni forzar código muerto en personajes simples.
  - *Alternativas descartadas*: Una máquina de estados genérica puramente JSON habría limitado la expresividad de habilidades únicas o requerido un lenguaje de scripting complejo.
- **Estado aislado (`customState`) vs. campos planos globales**:
  - *Enfoque elegido*: Mover todos los contadores y temporizadores específicos de personaje a un contenedor `player.custom` inicializado por el propio módulo del personaje.
  - *Por qué*: Elimina decenas de propiedades ajenas de la estructura global del jugador y garantiza reinicios limpios al cambiar de pirata.
- **Preservación estricta de gameplay durante la refactorización**:
  - *Enfoque elegido*: Ejecutar primero la migración de los 12 personajes y la generación dinámica de UI verificando paridad 1:1 de números, tiempos, VFX y sonidos; solo después aplicar las 4 correcciones de combate.
  - *Por qué*: Permite validar que la nueva arquitectura no alteró ni un solo parámetro involuntariamente antes de introducir los cambios de balance solicitados.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                         REGISTRO DE PERSONAJES                          │
│  Catálogo central (ID, stats, rareza, ficha selector, tema, hooks)      │
└───────────────┬─────────────────────────────┬───────────────────────────┘
                │                             │
                ▼                             ▼
┌───────────────────────────────┐  ┌──────────────────────────────────────┐
│    INTERFAZ Y SELECTOR DINÁMICO│  │       NÚCLEO DE COMBATE Y BUCLE      │
│ • Genera tarjetas y puntos     │  │ • Despacha ataque/dash/skill/update  │
│ • Renderiza HUD de recurso/btns│  │ • Pasa contexto y helpers comunes    │
│ • Sincroniza estado de botones │  │ • Ejecuta hooks pasivos (hit/kill)   │
└───────────────┬───────────────┘  └───────────────┬──────────────────────┘
                │                                  │
                └──────────────┬───────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   RENDERIZADOR DESACOPLADO (CANVAS 2D)                  │
│ • Base común: sombra, squash & stretch, rotación y auras                │
│ • Delegación al renderer del personaje (combate + preview del selector) │
│ • VFX especiales delegados o compartidos                                │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Registro de personaje (`CharacterModule`)**:
  - **Datos base**: Identificador, nombre, rareza, retrato, fondo, icono de ataque, tema CSS, paleta, estadísticas base (`hp`, `damage`, `speed`, `armor`, `dashCd`, `initialDashCharges`, `autoAimRange`), definición de las 3 habilidades y ficha descriptiva para el selector (`role`, `comboDesc`, `skillsDesc`).
  - **Ciclo de vida y acciones**: `createCustomState()`, `onAttack(ctx)`, `onDash(ctx)`, `onSkill(ctx, idx)`, `onUpdate(ctx, dt)`, además de hooks opcionales `onHoldSkillStart/End` (para habilidades cargadas como King Kong Gun), `canUseSkill/Dash/Attack`, `onDealDamage`, `onTakeDamage`, `onEnemyKilled`, `onEnemyProjectileUpdate`, `onVictory/onGameOver`.
  - **Descriptor de HUD y botones**: Definición declarativa del recurso principal (barra o cargas) y adaptadores opcionales para etiquetas dinámicas, candados o botones de cancelación.
  - **Renderizado**: `drawBody(ctx, renderCtx, mode)` para dibujar tanto en combate como en la vista previa del carrusel, más hooks opcionales de zona/aura en el mundo.
- **Estado del jugador**:
  - Conserva exclusivamente física, combate básico, cooldowns genéricos y squash & stretch comunes; toda lógica propia vive dentro de `player.custom`.

### Interactive Component & State Mapping

- **Carrusel de selección**: Se construye leyendo la lista ordenada de personajes registrados; los listeners táctiles y de clic usan el identificador de cada tarjeta generada y sincronizan automáticamente los puntos de paginación y las barras de estadísticas.
- **Botones de combate y teclado**:
  - En lugar de consultar nombres fijos de personajes para cargas sostenidas (como H3 de Luffy PTS), el gestor de entrada consulta los hooks genéricos del módulo activo (`supportsHoldSkill(idx)`, `onSkillRelease(idx)`, `isActionBlocked()`).
- **Motor de entidades y daño**:
  - Las interacciones especiales (como ralentización dentro de ROOM, reducción de daño recibido en transformación, esquiva absoluta en Future Sight, marcas/sangrados o ganancia de recurso por baja/parry) se invocan mediante hooks de personaje (`onEnemyTick`, `onEnemyKilled`, `onBeforePlayerDamage`, `onCalculateDamage`, `onProjectileTick`), eliminando por completo las referencias a `charId` en el motor genérico.
- **Ajustes finales de mecánicas (post-refactorización)**:
  1. **Gear 2nd (Luffy PTS)**: Activación permitida cuando `g2 > 0` (con umbral mínimo configurable o inmediato al tener energía); mientras está activo, `g2` decrece a tasa constante por segundo hasta `0`, bloqueando cualquier ganancia nueva de `g2`. Al llegar a `0`, se desactiva Gear 2nd, aplica el cooldown de H2 (18s) y vuelve a habilitar la recarga por eliminaciones.
  2. **Island Shaking H3 (Barbablanca)**: Activación cuando `gura > 0` (si está vacía, muestra aviso de energía insuficiente o mantiene una duración mínima nula según energía disponible — consumiendo la barra continuamente mientras la zona esté activa). Al llegar `gura` a `0` o al pulsar `CANCEL`, se cierra la zona sísmica con su transición suave, H3 entra en cooldown (20s) y la energía Gura puede volver a cargarse.
  3. **Cola de Franky en Coup de Vent (H3)**: Al ejecutar H3, consume toda la `cola` disponible (`cola / maxCola` de `0.0` a `1.0`) y aplica escalado lineal continuo tanto al multiplicador de daño como al radio/alcance del cono y partículas (conservando la mejora adicional si está al máximo o potenciándola de forma fluida desde 0% hasta 100%).
  4. **Combo básico de Luffy PTS**: En el 4º golpe (`Jet Bazooka`), reemplazar `attackCooldown = 1.0` por una cadencia fluida coherente con el resto del combo (`0.35 * g2Mult` o estándar del combo) y eliminar la condición especial que dibujaba cooldown sobre el botón de ataque básico.

### Verification Strategy

- Verificar tras la fase de refactorización (antes de los 4 ajustes) que compilación, tipado estricto (`tsc --noEmit`), pruebas unitarias y simulación en vivo de los 12 personajes en navegador mantienen 100% de paridad sin errores de consola.
- Añadir pruebas unitarias específicas para el registro de personajes y las 4 nuevas reglas de combate (drenaje de G2/Gura sin recarga activa, escalado de área/daño de Coup de Vent por Cola y ausencia de bloqueo de 1.0s en Luffy PTS), y validar todo el flujo en navegador tras la fase final.
